<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ptc extends Model
{
    protected $guarded = ['id'];
}
